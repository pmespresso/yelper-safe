var _ = require('lodash');
var ENDPOINT = 'https://api.yelp.com/v2/search/?location=San Francisco, CA';
/**
 * The YELP REST Node Module
 */
var OAuth = require('oauth-request-promise');
var yelp = OAuth({
    consumer: {
		public: 'i1B0Q5W-4niuMK-DsJxRgg',
		secret: '18yI6hwrPRVgVEWQcZg7tAuFThw'
	}
});

yelp.setToken({
    public: 'dQvi7opv3NzppLoYEDcnDypTVBmQL_QJ',
    secret: 'iRmUUD6Ou8P-lyXmAQ_aQhMqvM8'
});

function YelpDataHelper() { }

YelpDataHelper.prototype.requestYelpStatus = function () {
	return this.getYelpRestaurants().then(
		function(response) {
			console.log('success - received info from Yelp');
			console.log(response.body);
			return response.body;
			}
		);
};

YelpDataHelper.prototype.getYelpRestaurants = function () {
	return yelp.get({
	   url: ENDPOINT,
	   resolveWithFullResponse: true,
	   json: true
	});
};

YelpDataHelper.prototype.formatRestaurantNameAndType = function(data) {
	var restaurants = _.template('You should check out ${restaurantName}. They have ${restaurantType} food')({
    restaurantName: data.businesses[0].name,
    restaurantType: data.businesses[0].categories[0]
  });
	return restaurants;
};

module.exports = YelpDataHelper;